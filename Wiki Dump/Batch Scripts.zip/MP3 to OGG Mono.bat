@echo off
echo on
for %%a in (%*) do ffmpeg -i %%a -vn -map_metadata -1 -acodec libvorbis -b:a 96k -ac 1 "%%~na.ogg"
pause